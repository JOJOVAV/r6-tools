How to setup:
In cheat engine 6.1+svn go to settings->plugins and click add.
Then find stealthedit.dll and add it to the plugin list.
Check the checkbox left of it to enable it and click ok to exit the settings screen

And make sure you've configured your bios to ALLOW the no-execute ability

How to use:
-On the run-
Rightclick the page you want to stealthedit, and choose stealthedit. It will then automatically make an adjusted copy of the current page and configures the driver part to let executions of the original code go to the copy

-Auto assembler-
The stealthedit plugin adds a new auto assembler commands

stealthedit(name, address, size) - stealthedit the page and make a full module copy (size is ignored. It's only that specific page)
stealtheditex(name, address, pagecountoverhead) - stealthedit the page and make a small modified copy of the region you're stealthediting. the pagecount overhead defines how many pages before and after are copied and adjusted.



How it works internally:
A copy of the target memory is created and execution is rerouted to go through that copy. In 32-bit the copy is a 1 on 1 copy, in 64-bit (or in case of stealtheditex/region copy) the copy is adjusted so EIP/RIP relative instructions point to their original address


Known problems:
The copy stealthedit makes isn't always 100% perfect (it's based on automated disassembling and adjusting the calls, if the instructions arn't aligned properly, errors can/will occur). In case that you detect a problem (app/game crashes) inspect the copy of the memory and see what went wrong, and try to fix them yourself. Either making a full adjusted copy yourself, or just fixing the small incosistencies (e.g the first few/last instructions)

The auto assembler script part can come in use here, as name will be seen as the address of the copy, so you can use that to write the copy yourself
